package com.transsion

public class ResultInfo{

    long beforeSize;
    long afterSize;
    int compressedSize;
    int skipCount;
}