package com.transsion;

public class Constants {
    public static final String EXT_OPT = "imgCompressOpt"
    public static final String WAY_TINY="tinypng"
    public static final String WAY_QUANT="pngquant"
    public static final String WAY_ZOPFLIP="zopflip"
    public static final String TASK_NAME = "ImgCompressTask"
}
