### tiny key 申请教程

1. 进入官网[https://tinypng.com/developers](https://tinypng.com/developers),通过邮箱注册
2. tiny每个月会有500张免费的压缩额度,一般的版本迭代节奏都是够用的,不够用就再申请一个账号就有另外500张,而且本插件是会记录已压缩的图片,故不会重复压缩,节省了额度

